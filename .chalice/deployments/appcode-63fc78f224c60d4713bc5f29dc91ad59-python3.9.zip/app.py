from chalice import Chalice
import os

app = Chalice(app_name="predictor")

@app.route("/", methods=["GET"])
def index():
    return os.environ.get("MY_VAR", "dev")