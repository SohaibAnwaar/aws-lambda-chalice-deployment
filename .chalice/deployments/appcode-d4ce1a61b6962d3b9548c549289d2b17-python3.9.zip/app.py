from chalice import Chalice

app = Chalice(app_name="predictor")

@app.route("/", methods=["POST"])
def index():
    return ""